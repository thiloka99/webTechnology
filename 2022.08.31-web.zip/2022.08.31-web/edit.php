<?php
?>

<form method="post">
 Id : <input type="text" name="id" 
</form>