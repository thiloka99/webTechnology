<html>
  <head>
  <head>
  
  <body>
  <?php 
    include ('connection.php');
	$firstName = "";
	$lastName = "";
	$address = "";
	$mobile = "";
	$gender = "";
	$nic = "";
	$dob = "";
	$District = "";
	$Name_of_MOH = "";
	$userName = "";
	$password = "";
	$update = false;
	
	if(isset($_POST["update"])){
		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		$address = $_POST['address'];
		$mobile = $_POST['mobile'];
		$gender = $_POST['gender'];
		$nic = $_POST['nic'];
		$dob = $_POST['dob'];
		$District = $_POST['District'];
		$Name_of_MOH = $_POST['Name_of_MOH'];
		$userName = $_POST['userName'];
		$password = $_POST['password'];
		
		$query = "UPDATE moh_table SET firstName='$firstName', lastName='$lastName', address='$address', mobile='$mobile', gender='$gender', nic='$nic', dob='$dob', District='$District', Name_of_MOH='$Name_of_MOH', userName='$userName', password='$password'";
		$con->query($query);
		$_SESSION['message'] = "Members details update!";
		header("location:admin.php");
	}
	
   ?>
    <form>
	  First Name : <input type="text" name="firstName" value="<?php echo $firstName ?>"><br><br>
	  Last Name : <input type="text" name="lastName" value="<?php echo $lastName ?>"><br><br>
	  Address : <input type="text" name="address" value="<?php echo $address ?>"><br><br>
	  Mobile No : <input type="text" name="mobile" value="<?php echo $mobile ?>"><br><br>
	  Gender : <select name="gender" value="<?php echo $gender ?>">
	  <option>Female</option>
	  <option>Male</option>
	  </select><br><br>
	  
	  NIC : <input type="text" name="nic" value="<?php echo $nic ?>"><br><br>
	  Date of Birth : <input type="text" name="dob" value="<?php echo $dob ?>"><br><br>
	  District :  <select name="District" value="<?php echo $District ?>">
	   <option>Jaffna</option>
	   <option>Colombo</option>
	   <option>Gampaha</option>
	   <option>Vavuniya</option>
	  </select><br><br>
	  
	  MOH : <select name="Name_of_MOH" value="<?php echo $Name_of_MOH ?>">
	  <option>Jaffna</option>
	 <option>Vavuniya</option>
	 <option>Anuradapura</option>
	 <option>colombo</option>
	 </select><br><br>
	 
	 User Name : <input type="text" name="userName" value="<?php echo $userName ?>"><br><br>
	 Password : <input type="password" name="password" value="<?php echo $password ?>"><br><br>
	 Re-Password : <input type="password" name="password"><br><br>
     <?php 
	 if($update){ ?>
	 <input type="submit" name="update" value="update">
     <?php }else ?>
	 <?php {?> 
	 <input type="submit" name="add" value="add">
	 <?php } ?>
	 <input type="reset" name="clear" value="clear">
	</form>
  </body>
</html>