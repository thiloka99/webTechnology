<html>
   <head>
     <title>Admin</title>
   </head>
   
   <body>
   <?php 
    include ('connection.php');
	$Id = "";
	$District = "";
	$Name_of_MOH = "";
	$firstName = "";
	$lastName = "";
	$address = "";
	$mobile = "";
	$password = "";
	
	if(isset($_POST["add"])){
		$Id = $_POST['Id'];
		$District = $_POST['District'];
		$Name_of_MOH = $_POST['Name_of_MOH'];
		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		$address = $_POST['address'];
		$mobile = $_POST['mobile'];
		$password = $_POST['password'];
		
		$query = "INSERT INTO moh_table(Id, District, Name_of_MOH, firstName, lastName, address, mobile, password) VALUES ('$Id', '$District', '$Name_of_MOH', '$firstName', '$lastName','$address', '$mobile', '$password')";
		if($con->query($query)){ //mysqli_query($con, $sql)--- prosedural style
		echo "Successfuly !!";
			header("location:admin.php");
		}
		else{
			echo "connection error: ".$con->connect_error;
		}
	}
	
	
   ?>
     <form action="" method="post">
		 MOH ID : <input type="text" name="Id" value="<?php echo $Id ?>"><br><br>
		 District : <input type="text" name="District" value="<?php echo $District ?>"><br><br>
		 Name of the MOH : <select name="Name_of_MOH" value="<?php echo $Name_of_MOH ?>">
		 <option>Jaffna</option>
		 <option>Vavuniya</option>
		 <option>Anuradapura</option>
		 <option>colombo</option>
		 </select><br><br>
		 
		 First Name : <input type="text" name="firstName" value="<?php echo $firstName ?>" ><br><br>
		 Last Name : <input type="text" name="lastName" value="<?php echo $lastName ?>" ><br><br>
		 Address : <input type="text" name="address" value="<?php echo $address ?>" ><br><br>
		 Mobile no : <input type="text" name="mobile" value="<?php echo $mobile ?>" ><br><br>
		 Password : <input type="password" name="password" value="<?php echo $password ?>" ><br><br>
		 
		 <button type="submit" name="add" value="add"> Add </button>
		 <button type="reset" name="clear" value="clear"> Clear </button>
	 </form>
   </body>
</html>