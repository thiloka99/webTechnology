<?php
interface Sellable{//can not have any instern variable eg: $name, $age
	public function addStock($num);//should all are public
	public function sellItem();
	public function getStockCount();
}
class Television implements Sellable{
	private $screenSize;
	private $stockCount;
	
	public function getScreenSize(){
		return $this->screenSize;
	}
	public function setScreenSize($s){
		$this->screenSize = $s;
	}
	public function addStock($num){
		$this->stockCount += $num;
	}
	public function sellItem(){
		$this->stockCount -= 1;
	}
	public function getStockCount(){
		return $this->stockCount;
	}
}
$tv1 = new Television();//create object for Television 

$tv1->setScreenSize("14");
$tv1->addStock(50);
print($tv1->getStockCount());
echo "<br>";
$tv1->sellItem();
print($tv1->getStockCount());
Echo "<br>";

class TennisBall implements Sellable{
	private $count;
	private $color;
	
	public function getColor(){
		return $this->color;
	}
	public function setColor($c){
		$this->color = $c;
	}
	public function addStock($num){
		$this->count += $num;
	}
	public function sellItem(){
		$this->count -= 1;
	}
	public function getStockCount(){
		return $this->count;
	}
}
$tb1 = new TennisBall();//create object for TennisBall

$tb1->setColor("Blue");
$tb1->addStock(60);
print($tb1->getStockCount());
echo "<br>";
$tb1->sellItem();
print($tb1->getStockCount());
	

?>