<?php
abstract class shape{
	protected $color;
	protected $filled;
	
	public function __construct($col,$isFilled){
		$this->color = $col;
		$this->isFilled = $isFilled;
	}
	abstract public function getArea();
	
	public function setColor($col){
		echo "I am from parent class";
		$this->color = $col;
	}
	public function getColor(){
		return $this->color;
	}
	public function isFilled(){
		return $this->isFilled;
	}
	public function makeHollow(){
		$this->isFilled = false;
	}
	public function fill(){
		$this->isFilled = true;
	}
}

class square extends shape{
	private $length;
	
	public function __construct($col, $isFilled, $L){
		parent::__construct($col,$isFilled);//private parent class eke athribute 
		$this->length = $L;
	}
	public function setColor($col){
		//$this->color = $col;
		echo "Setting up the color as {$this->color}<br>";
		
	}
	public function setLength($L){
		$this->length = $L;
	}
	public function getLength(){
		return $this->length;
	}
	public function getArea(){
		return $this->length*$this->length;
	}
}

class circle extends shape{
	private $radious;
	
	public function __construct($col, $isFilled, $r){
		parent::__construct($col, $isFilled);
		$this->radious = $r;
	}
	public function getRadious(){
		return $this->radious;
	}
	public function setRadious($r){
		$this->radious = $r;
	}
	public function getArea(){
		return M_PI * pow($this->radious,2);
	}
}
//if shape is abstract do not create object in this calss
$s1 = new square("Green", true, 8);
//$s1->setColor("Pink");
echo $s1->setColor("Green");

$c1 = new circle("White", true,6);
$c1->setRadious(9);
$c1->setColor("blue");

//$shape1 = new shape("Red", true);
//print_r($shape1);
//echo "<br>".$shape1->getColor();

echo "<br>";
print($c1->getArea());
?>