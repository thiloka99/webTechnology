<html> 
  <head>
  <title>Customer Registration</title>
  <style>
  
    .aaa{
		
		border: 2px solid blue;
		padding: 10px 30px 100px;
		
	}
	</style>
  </head>
  <body align="center">
  <div class="aaa" style="margin: 10px 500px">
   <form action="registration.php" method="post">
    Name: <input type="text" name="name" value="<?php echo $name ?>"><br><br>
	Email: <input type="text" name="email" value="<?php echo $email ?>"><br><br>
	Gender: <select name="gender" value="<?php echo $gender ?>">
	     <option>Female</option>
	     <option>Female</option>
	</select><br><br>
	Address: <input type="text" name="address" value="<?php echo $address ?>"><br><br>
	Mobile No: <input type="number" name="mobile" value="<?php echo $mobile ?>"><br><br>
	Password: <input type="password" name="password" value="<?php echo $password ?>"><br><br>
	<input type="submit" name="signUp" value="signUp">
   </form>
   <div>
  </body>

</html>