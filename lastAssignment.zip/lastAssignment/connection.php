<?php
   $host = "localhost";
   $user = "root";
   $password = "";
   $dbname = "esms";
   $con = mysqli_connect($host, $user, $password, $dbname);
   if($con->connect_error){
	   die("connection failed:" .$conn->connect_error);
   }

?>