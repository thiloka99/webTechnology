<html>
  <head>
    <title>E-Store</title>
	<style>
	
	 .aaa{
		border: 2px solid blue;
		padding: 10px 30px;
	}
	</style>
  </head>
  <body align="center">
   <div class="aaa" style="margin: 10px 500px">
     <form>
	   Email: <input type="text" name="email"><br><br>
	   Password: <input type="password" name="password"><br><br>
	   <input type="submit" name="login" value="login">
	 </form>
   </div>
  </body>
</html>