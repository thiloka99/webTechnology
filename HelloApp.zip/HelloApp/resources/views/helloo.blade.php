<html>
<h1>comeeee {{$msg}}</h1> <!-- $message = "Laravel user123456" -->

</html>