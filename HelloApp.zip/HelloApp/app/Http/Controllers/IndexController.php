<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function sayHello(){
        return view("helloo");
    }
    public function sayHello2(){
        $message = "Laravel user123456";
        return view("helloo",['msg'=>$message]);
    }
}
