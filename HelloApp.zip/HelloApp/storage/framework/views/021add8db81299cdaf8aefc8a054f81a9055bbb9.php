<html>
<h1>comeeee <?php echo e($msg); ?></h1> <!-- $message = "Laravel user" -->

</html><?php /**PATH C:\Users\E-Lab Staff\HelloApp\resources\views/helloo.blade.php ENDPATH**/ ?>