<html>
    <body>
        <h1>helloo index</h1>
    </body>
</html><?php /**PATH C:\Users\E-Lab Staff\HelloApp\resources\views/index.blade.php ENDPATH**/ ?>